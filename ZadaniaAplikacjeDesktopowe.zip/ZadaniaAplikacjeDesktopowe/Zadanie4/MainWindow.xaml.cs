﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zadanie4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Kalkulator kalkulator = new Kalkulator();
        public MainWindow()
        {
            DataContext = kalkulator;
            InitializeComponent();
        }

        private void Cyfra(object sender, RoutedEventArgs e)
        {
            kalkulator.DopiszCyfrę(
                ((Button)sender).Content.ToString()
                );
        }

        private void ZmieńZnak(object sender, RoutedEventArgs e)
        {
            kalkulator.ZmieńZnak();
        }

        private void ZacznijUłamek(object sender, RoutedEventArgs e)
        {
            kalkulator.ZacznijUłamek();
        }

        private void ZerujWynik(object sender, RoutedEventArgs e)
        {
            kalkulator.ZerujWynik();
        }

        private void ZerujWszystko(object sender, RoutedEventArgs e)
        {
            kalkulator.ZerujWszystko();
        }

        private void UsuńCyfrę(object sender, RoutedEventArgs e)
        {
            kalkulator.UsuńCyfrę();
        }

        private void Działanie(object sender, RoutedEventArgs e)
        {
            kalkulator.WprowadźDziałanie(
                ((Button)sender).Content.ToString()
                );
        }

        private void RównaSię(object sender, RoutedEventArgs e)
        {
            kalkulator.WykonajDziałanie();
        }
    }
}
