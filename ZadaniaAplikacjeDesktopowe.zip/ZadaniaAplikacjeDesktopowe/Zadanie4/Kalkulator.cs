﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie4
{
    internal class Kalkulator : INotifyPropertyChanged
    {
        static HashSet<string> DziałaniaJednoargumentowe = new() {
            "¹⁄ₓ", "x²", "√"
        };
        public event PropertyChangedEventHandler? PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(propertyName)
                );
        }

        double?
            argumentLewy = null,
            argumentPrawy = null
            ;
        string?
            buforDziałania = null
            ;
        bool
            działanieWykonane = false;

        public string Bufory {
            get {
                if (argumentLewy == null)
                    return "";
                else if (argumentPrawy == null)
                    return $"{argumentLewy} {buforDziałania}";
                else
                    return $"{argumentLewy} {buforDziałania} {argumentPrawy}";
            }
        }

        public string Wynik { get; set; } = "0";

        public void DopiszCyfrę(string cyfra)
        {
            if(Wynik == "0")
                Wynik = cyfra;
            else
                Wynik += cyfra;
            OnPropertyChanged("Wynik");
        }
        public void ZmieńZnak()
        {
            if (Wynik == "0")
                return;
            else if (Wynik[0] == '-')
                Wynik = Wynik.Substring(1);
            else
                Wynik = "-" + Wynik;
            OnPropertyChanged("Wynik");
        }
        public void ZacznijUłamek()
        {
            if (Wynik.Contains(','))
                return;
            else
                Wynik += ",";
            OnPropertyChanged("Wynik");
        }
        public void ZerujWynik()
        {
            Wynik = "0";
            OnPropertyChanged("Wynik");
        }
        public void ZerujWszystko()
        {
            Wynik = "0";
            buforDziałania = null;
            argumentLewy = argumentPrawy = null;
            działanieWykonane = false;
            OnPropertyChanged("Wynik");
            OnPropertyChanged("Bufory");
        }
        public void UsuńCyfrę()
        {
            if (Wynik == "0")
                return;
            else if (Wynik == "-0," || Wynik.Length == 1)
                Wynik = "0";
            else
                Wynik = Wynik.Substring(0, Wynik.Length - 1);
            OnPropertyChanged("Wynik");
        }
        public void WprowadźDziałanie(string działanie)
        {
            if (buforDziałania != null)
                WykonajDziałanie();
            if (działanieWykonane)
                argumentPrawy = null;
            
            buforDziałania = działanie;
            argumentLewy = Convert.ToDouble(Wynik);
            if (DziałaniaJednoargumentowe.Contains(buforDziałania))
            {
                WykonajDziałanie();
                argumentPrawy = null;
            }
            Wynik = "0";
            OnPropertyChanged("Bufory");
        }
        public void WykonajDziałanie()
        {
            if (argumentLewy == null || buforDziałania == null)
                return;
            if (argumentPrawy == null)
                argumentPrawy = Convert.ToDouble(Wynik);
            OnPropertyChanged("Bufory");

            if (buforDziałania == "+")
                argumentLewy += argumentPrawy;
            else if (buforDziałania == "-")
                argumentLewy -= argumentPrawy;
            else if (buforDziałania == "x²")
                argumentLewy *= argumentLewy;
            else if (buforDziałania == "√")
                argumentLewy = Math.Sqrt((double)argumentLewy);
            else if (buforDziałania == "×")
                argumentLewy *= argumentPrawy;
            else if (buforDziałania == "÷")
                argumentLewy /= argumentPrawy;
            else if (buforDziałania == "¹⁄ₓ")
                argumentLewy = 1 / argumentLewy;
            else if (buforDziałania == "%")
                argumentLewy *= argumentPrawy/100;
            Wynik = argumentLewy.ToString();
            OnPropertyChanged("Wynik");
            działanieWykonane = true;
        }
    }
}
