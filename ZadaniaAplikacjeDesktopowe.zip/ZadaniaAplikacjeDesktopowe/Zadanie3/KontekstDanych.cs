﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie3
{
    internal class KontekstDanych : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        private Dictionary<string, string[]> powiązaneWłaściwości = new()
        {
            ["DataUrodzenia"] = new string[] { "Wiek" },
        };
        protected void NotyfikujZmianęWłaściwości(
            [CallerMemberName] string nazwaWłaściwości = null
            )
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(nazwaWłaściwości)
                );
            if (powiązaneWłaściwości.ContainsKey(nazwaWłaściwości))
                foreach (string powiązanaWłaściwość in powiązaneWłaściwości[nazwaWłaściwości])
                    NotyfikujZmianęWłaściwości(powiązanaWłaściwość);
        }

        private string
            imię = "",
            nazwisko = "",
            imięNazwisko = ""
            ;
        private DateTime dataUrodzenia;
        public string ImięNazwisko
        {
            get => imięNazwisko;
            set
            {
                imięNazwisko = value;
                string[] imięiNazwisko = imięNazwisko.Split(' ');
                Imię = imięiNazwisko.First();
                Nazwisko = imięiNazwisko.Last();
                NotyfikujZmianęWłaściwości();
            }
        }
        public string Imię
        {
            get => imię;
            set
            {
                imię = value;
                NotyfikujZmianęWłaściwości();
            }
        }
        public string Nazwisko
        {
            get => nazwisko;
            set
            {
                nazwisko = value;
                NotyfikujZmianęWłaściwości();
            }
        }
        public DateTime DataUrodzenia
        {
            get => dataUrodzenia;
            set
            {
                dataUrodzenia = value;
                NotyfikujZmianęWłaściwości();
            }
        }
        public uint Wiek
        {
            get
            {
                TimeSpan przedział = DateTime.Now - DataUrodzenia;
                return (uint)Math.Round(przedział.Days / 365.25);
            }
        }
    }
}
